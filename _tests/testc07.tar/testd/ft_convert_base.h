#include <stdlib.h>
/*
typedef enum e_sign
{
	positive = 1,
	negative = -1
}	t_sign;
typedef unsigned int	t_ui;

int	ft_strlen(char *str);
int	get_cvalue(char c, char *base);
int	is_space(char c);
int	is_sign(char c);
int	switch_sign(t_sign sign, char *nbr);
int	ft_strlen(char *str);
int	get_cvalue(char c, char *base);
int	is_space(char c);
int	is_sign(char c);
int	switch_sign(int sign, char *nbr);
*/
char	*ft_convert_base(char *nbr, char *base_from, char *base_to);
